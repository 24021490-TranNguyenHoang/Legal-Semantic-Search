# Gói thiết kế mô hình dữ liệu VTLS v1.0

Snapshot sản phẩm: 2025-01-01. Đây là schema và fixture kiểm tra cấu trúc; không phải corpus pháp luật đã làm sạch.

## Nội dung
- schema.sql: 12 bảng lõi và view serving_chunks trong SQLite.
- data_dictionary.json: trường, kiểu và quy tắc, đồng bộ tài liệu DOCX.
- erd_sources.mmd, erd_corpus.mmd: mã Mermaid có thể chỉnh sửa.
- chunk.schema.json: hợp đồng JSON Schema Draft 2020-12 cho mỗi dòng chunks.jsonl.
- eval_schema.sql: kho đánh giá riêng; cần kiểm tra corpus/chunk và split bằng CLI.
- validate_design.py: validator cấu trúc, standard library Python 3.9+.
- fixture.* và fixture_*.txt/json: ví dụ giả lập. Không nhập vào corpus thật.
- verification_report.json: kết quả các ca kiểm tra schema và tính nhất quán.

## Chạy
python validate_design.py --self-test
python validate_design.py --db staging.sqlite --artifact-root /path/to/artifact/root

Với jsonschema: dùng Draft202012Validator(schema, format_checker=FormatChecker()).
Tạo SQLite bằng executescript(schema.sql), bật PRAGMA foreign_keys=ON trên từng kết nối ghi trước transaction.

## Điều kiện ngoài validator mẫu
Xác minh nguồn chính thức, nội dung OCR/HTML so với bản gốc, hiệu lực và chuyển tiếp, đủ tệp/phụ lục, bộ ba chỉ mục, manifest/checksum và immutable release là các cổng phát hành phải triển khai/rà soát thêm. View serving_chunks một mình không bảo đảm context hợp lệ. Corpus chỉ được đưa vào ứng dụng sau khi mọi cổng đã đạt.

## Offset và tái lập
Mọi offset [start,end) tính theo Unicode code point, không phải byte hay token. source_span trỏ extraction NFC/LF đã đóng băng; legal_unit field được dựng bằng LF nối các span_order. chunk/context trỏ field của legal_unit. Thay extraction hoặc unit tạo ID/artifact mới, không sửa offsets cũ.

## Không gian UUID Qdrant
Chọn một UUID namespace của dự án và ghi nguyên giá trị vào processing/index config. Ví dụ fixture có thể dùng UUID 5f1c3be0-248e-5df3-92cc-b1b93b733575; production phải khóa cùng giá trị trong mọi lần build. Tên uuid5 là corpus_version + LF + chunk_id.
