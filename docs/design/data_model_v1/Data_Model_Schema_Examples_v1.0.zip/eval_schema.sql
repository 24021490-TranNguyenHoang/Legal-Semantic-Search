-- Optional offline evaluation database. IDs are scoped to a frozen dataset.
PRAGMA foreign_keys=ON;
CREATE TABLE eval_dataset (
 dataset_version TEXT PRIMARY KEY NOT NULL, corpus_version TEXT NOT NULL,
 annotation_version TEXT NOT NULL, guideline_version TEXT NOT NULL,
 reviewer_ref TEXT NOT NULL, review_status TEXT NOT NULL,
 manifest_ref TEXT NOT NULL
);
CREATE TABLE eval_query (
 dataset_version TEXT NOT NULL REFERENCES eval_dataset(dataset_version),
 query_id TEXT NOT NULL, query TEXT NOT NULL,
 query_type TEXT NOT NULL CHECK(query_type IN ('direct','paraphrase','scenario')),
 topic TEXT NOT NULL, intent_group_id TEXT NOT NULL,
 split TEXT NOT NULL CHECK(split IN ('dev','test')),
 PRIMARY KEY(dataset_version,query_id)
);
CREATE TABLE eval_qrel (
 dataset_version TEXT NOT NULL, query_id TEXT NOT NULL, chunk_id TEXT NOT NULL,
 corpus_version TEXT NOT NULL, relevance INTEGER NOT NULL CHECK(relevance IN (0,1,2)),
 PRIMARY KEY(dataset_version,query_id,chunk_id),
 FOREIGN KEY(dataset_version,query_id) REFERENCES eval_query(dataset_version,query_id)
);
-- corpus/chunk compatibility is validated against the locked external corpus export.
-- Prevent intent_group_id appearing in both splits; validate in the evaluation CLI.
