"""Prototype VTLS structural validator, standard library only.
Run --self-test for synthetic fixtures; --db PATH --artifact-root DIR for staging.
This does not establish legal correctness or official-source authenticity.
"""
from pathlib import Path
import argparse, sqlite3, json, hashlib, unicodedata, datetime, urllib.parse

def digest(s): return hashlib.sha256(s.encode('utf-8')).hexdigest()
def canonical(o): return json.dumps(o,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def unit_id(u):
    keys=['law_id','parent_unit_id','unit_type','designation','canonical_path','citation_path','ordinal','title','text_original']
    return 'u_'+digest(canonical({'identity_schema':'unit.v1',**{k:u[k] for k in keys}}))
def chunk_id(c,u,d,a,contexts):
    keys=['unit_id','segment_no','unit_char_start','unit_char_end','text_original','chunk_policy_version']
    obj={'identity_schema':'chunk.v1',**{k:c[k] for k in keys},'contexts':contexts}
    obj.update({k:d[k] for k in ['law_id','law_title','source_url']})
    obj['citation_path']=u['citation_path']
    obj.update({k:a[k] for k in ['effective_from','effective_to','applicability_status']})
    return 'c_'+digest(canonical(obj))
def rows(db,t):return [dict(r) for r in db.execute('SELECT * FROM '+t)]
def validate(db,root):
    root=Path(root).resolve();db.row_factory=sqlite3.Row;errors=[]
    def err(rule,msg):errors.append({'rule_id':rule,'message':msg})
    def readref(ref):
        p=(root/ref).resolve()
        if not p.is_relative_to(root):raise ValueError('path escapes artifact root')
        return p.read_bytes()
    fk=list(db.execute('PRAGMA foreign_key_check'))
    for r in fk:err('DQ-01','foreign key: '+str(tuple(r)))
    units={x['unit_id']:x for x in rows(db,'legal_unit')};docs={x['law_id']:x for x in rows(db,'legal_document')}
    corpora={x['corpus_version']:x for x in rows(db,'corpus')}
    assessments={(x['corpus_version'],x['unit_id']):x for x in rows(db,'unit_assessment')}
    files={x['file_id']:x for x in rows(db,'source_file')};extracts={};spans={}
    memberships={(x['corpus_version'],x['law_id']):x['usage_role'] for x in rows(db,'corpus_document')}
    for table,date_fields,time_fields in [
      ('legal_document',['issued_date','document_effective_from'],[]),
      ('source_file',[],['retrieved_at']),('extraction',[],['created_at']),
      ('corpus',['snapshot_date'],['built_at']),
      ('unit_assessment',['effective_from','effective_to'],['verified_at']),
      ('quality_issue',[],['created_at'])]:
        for obj in rows(db,table):
            for field in date_fields:
                if obj[field] is None:continue
                try:
                    if datetime.date.fromisoformat(obj[field]).isoformat()!=obj[field]:raise ValueError()
                except Exception:err('DQ-01','invalid date '+table+'.'+field)
            for field in time_fields:
                if obj[field] is None:continue
                try:
                    if not obj[field].endswith('Z'):raise ValueError()
                    datetime.datetime.fromisoformat(obj[field].replace('Z','+00:00'))
                except Exception:err('DQ-01','invalid UTC timestamp '+table+'.'+field)
    for d in docs.values():
        if not d['law_title'].strip() or not d['law_id'].strip():err('DQ-01','empty document identity/title')
        if urllib.parse.urlparse(d['source_url']).scheme not in ('http','https'):err('DQ-01','invalid document URL')
    for f in files.values():
        try:
            b=readref(f['raw_file_ref'])
            if len(b)!=f['size_bytes'] or hashlib.sha256(b).hexdigest()!=f['sha256']:err('DQ-01','raw hash/size '+f['file_id'])
        except Exception as ex:err('DQ-01','raw unavailable '+f['file_id']+': '+str(ex))
    for e in rows(db,'extraction'):
        try:
            b=readref(e['text_ref']);t=b.decode('utf-8');extracts[e['extraction_id']]=(e,t)
            if hashlib.sha256(b).hexdigest()!=e['text_sha256'] or len(t)!=e['char_count']:err('DQ-03','extraction checksum/length '+e['extraction_id'])
            if unicodedata.normalize('NFC',t)!=t or '\r' in t:err('DQ-05','extraction is not NFC/LF')
        except Exception as ex:err('DQ-03','extraction unavailable: '+str(ex))
    for u in units.values():
        if digest(u['text_original'])!=u['text_sha256'] or unit_id(u)!=u['unit_id']:err('DQ-06','unit hash/ID '+u['unit_id'])
        for k in ('title','text_original'):
            if unicodedata.normalize('NFC',u[k])!=u[k] or '\r' in u[k]:err('DQ-05','unit is not NFC/LF')
        seen={u['unit_id']};cur=u
        while cur['parent_unit_id']:
            pid=cur['parent_unit_id']
            if pid in seen:err('DQ-02','cycle '+u['unit_id']);break
            seen.add(pid)
            if pid not in units:err('DQ-02','missing parent');break
            cur=units[pid]
            if cur['law_id']!=u['law_id']:err('DQ-02','parent in another document')
        if u['parent_unit_id'] is None and u['unit_type']!='document':err('DQ-02','non-document root')
        if u['parent_unit_id'] is not None and u['unit_type']=='document':err('DQ-02','document node has parent')
    for lid in docs:
        if sum(u['law_id']==lid and u['parent_unit_id'] is None for u in units.values())<1:err('DQ-02','no root for '+lid)
    for s in rows(db,'source_span'):
        spans.setdefault((s['unit_id'],s['field_name']),[]).append(s)
    def check_provenance(uid,field):
        u=units[uid];items=sorted(spans.get((uid,field),[]),key=lambda x:x['span_order']);quotes=[]
        if not u[field]:return
        if not items:err('DQ-03','missing span '+uid+' '+field);return
        if [x['span_order'] for x in items]!=list(range(len(items))):err('DQ-03','span order has gap')
        for s in items:
            found=extracts.get(s['extraction_id'])
            if not found:err('DQ-03','missing extraction');continue
            e,t=found
            if e['review_status']!='verified':err('DQ-03','unverified extraction')
            f=files.get(e['file_id'])
            if not f or f['law_id']!=u['law_id']:err('DQ-03','source span belongs to another law')
            if not (0<=s['char_start']<s['char_end']<=len(t)):err('DQ-03','span offsets invalid');continue
            quote=t[s['char_start']:s['char_end']];quotes.append(quote)
            if digest(quote)!=s['quote_sha256']:err('DQ-03','span quote hash drift')
            loc=json.loads(s['locator_json'])
            if not isinstance(loc,dict) or not loc:err('DQ-03','locator missing')
        if '\n'.join(quotes)!=u[field]:err('DQ-05','unit text differs from source spans')
    used=set()
    def applicable(cv,uid,target):
        a=assessments.get((cv,uid));p=corpora.get(cv)
        if not a or not p:err('DQ-04','assessment/corpus missing');return None
        allowed=('included',) if target else ('included','supporting')
        if a['scope_status'] not in allowed or a['applicability_status']!='verified_at_snapshot':err('DQ-04','scope/applicability rejected')
        if not all(a.get(k) for k in ('effective_from','verification_ref','verified_at','reviewer_ref')):err('DQ-04','verification evidence missing')
        try:
            snap=datetime.date.fromisoformat(p['snapshot_date']);start=datetime.date.fromisoformat(a['effective_from'])
            end=datetime.date.fromisoformat(a['effective_to']) if a['effective_to'] else None
            if not (start<=snap and (end is None or snap<end)):err('DQ-04','unit not active at snapshot')
        except Exception:err('DQ-04','invalid effective dates')
        try:
            evidence=json.loads(readref(a['verification_ref']))
            if not evidence:err('DQ-04','empty verification artifact')
        except Exception:err('DQ-04','verification artifact unavailable')
        if uid in units:
            lid=units[uid]['law_id'];role=memberships.get((cv,lid))
            if role is None or (target and role!='retrieval'):err('DQ-04','document membership missing/invalid')
        used.add((cv,uid));return a
    allcontexts=rows(db,'chunk_context');groups={}
    for c in rows(db,'chunk'):
        cv,uid=c['corpus_version'],c['unit_id'];u=units.get(uid)
        if not u:continue
        a=applicable(cv,uid,True);d=docs.get(u['law_id'])
        groups.setdefault((cv,uid),[]).append(c)
        start,end=c['unit_char_start'],c['unit_char_end']
        if not (0<=start<end<=len(u['text_original'])) or c['text_original']!=u['text_original'][start:end]:err('DQ-05','target slice differs')
        check_provenance(uid,'text_original')
        cc=sorted((x for x in allcontexts if x['corpus_version']==cv and x['chunk_id']==c['chunk_id']),key=lambda x:x['context_order'])
        if [x['context_order'] for x in cc]!=list(range(len(cc))):err('DQ-05','context order has gap')
        chunks=[];fingerprint=[]
        for x in cc:
            xu=units.get(x['unit_id']);applicable(cv,x['unit_id'],False)
            if not xu:continue
            check_provenance(x['unit_id'],x['field_name']);t=xu[x['field_name']]
            if not (0<=x['char_start']<x['char_end']<=len(t)):err('DQ-05','context offsets invalid')
            chunks.append(t[x['char_start']:x['char_end']])
            fingerprint.append({k:x[k] for k in ['unit_id','field_name','char_start','char_end','context_role','context_order']})
        context='\n'.join(chunks) if chunks else None
        if c['context_text']!=context:err('DQ-05','context text differs from fragments')
        search='\n\n'.join([d['law_title'],u['citation_path']]+([context] if context else [])+[c['text_original']])
        if c['text_for_search']!=search or digest(search)!=c['content_sha256']:err('DQ-06','search text/hash differs')
        if a and d and chunk_id(c,u,d,a,fingerprint)!=c['chunk_id']:err('DQ-06','chunk identity differs')
    for key,cs in groups.items():
        ordered=sorted(cs,key=lambda x:x['segment_no']);end=0
        if [c['segment_no'] for c in ordered]!=list(range(1,len(ordered)+1)):err('DQ-05','segment numbers have gap')
        for c in ordered:
            if c['unit_char_start']!=end:err('DQ-05','target segments overlap or omit text')
            end=c['unit_char_end']
        if end!=len(units[key[1]]['text_original']):err('DQ-05','target segments do not cover entire unit')
    for r in rows(db,'legal_reference'):
        if (r['resolution_status']=='resolved')!=(r['to_unit_id'] is not None):err('DQ-02','reference status/target mismatch')
    active_paths={}
    for cv,uid in used:
        if uid not in units:continue
        u=units[uid];key=(cv,u['law_id'],u['canonical_path'])
        if key in active_paths and active_paths[key]!=uid:err('DQ-02','multiple revisions of one legal position in corpus')
        active_paths[key]=uid
    for q in rows(db,'quality_issue'):
        if q['severity']=='error' and (q['status']=='open' or (q['status']=='excluded' and (q['unit_id'] is None or (q['corpus_version'],q['unit_id']) in used))):err('DQ-09','unresolved/served excluded error '+q['issue_id'])
    return errors

def load_fixture(root):
    db=sqlite3.connect(':memory:');db.row_factory=sqlite3.Row
    db.executescript((root/'schema.sql').read_text(encoding='utf-8'))
    for table,items in json.loads((root/'fixture.tables.json').read_text(encoding='utf-8')).items():
        for obj in items:
            cols=list(obj);db.execute('INSERT INTO '+table+' ('+','.join(cols)+') VALUES ('+','.join('?' for _ in cols)+')',[obj[x] for x in cols])
    db.commit();return db

def self_test(root):
    results=[]
    db=load_fixture(root);base=validate(db,root);results.append({'case':'valid synthetic graph','passed':not base,'errors':base})
    cases=[
      ('future context',"UPDATE unit_assessment SET effective_from='2026-01-01' WHERE scope_status='supporting'",'DQ-04'),
      ('context text tampered',"UPDATE chunk SET context_text='tampered'",'DQ-05'),
      ('target offset drift',"UPDATE chunk SET unit_char_start=1",'DQ-05'),
      ('search hash tampered',"UPDATE chunk SET content_sha256='"+'0'*64+"'",'DQ-06'),
      ('missing provenance',"DELETE FROM source_span",'DQ-03'),
      ('context excluded by scope',"UPDATE unit_assessment SET scope_status='excluded' WHERE scope_status='supporting'",'DQ-04'),
      ('pending extraction',"UPDATE extraction SET review_status='pending'",'DQ-03'),
      ('end date equals snapshot',"UPDATE unit_assessment SET effective_from='2024-01-01', effective_to='2025-01-01'",'DQ-04'),
    ]
    for label,stmt,expected in cases:
        db=load_fixture(root);db.execute(stmt);errs=validate(db,root)
        results.append({'case':label,'passed':expected in {e['rule_id'] for e in errs},'expected_rule':expected})
    db=load_fixture(root)
    try:
        db.execute("UPDATE legal_unit SET parent_unit_id='missing' WHERE unit_type='clause'")
        ok=False
    except sqlite3.IntegrityError:ok=True
    results.append({'case':'foreign key rejects missing parent','passed':ok})
    return {'fixture_is_synthetic':True,'legal_corpus_verified':False,'passed':all(x['passed'] for x in results),'cases':results}

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--self-test',action='store_true');a.add_argument('--db');a.add_argument('--artifact-root',default=str(Path(__file__).parent));args=a.parse_args();root=Path(args.artifact_root)
    if args.self_test:report=self_test(root);ok=report['passed']
    else:
        if not args.db:a.error('--db is required unless --self-test')
        db=sqlite3.connect(args.db);errors=validate(db,root);report={'passed':not errors,'errors':errors};ok=not errors
    print(json.dumps(report,ensure_ascii=False,indent=2));raise SystemExit(0 if ok else 1)
