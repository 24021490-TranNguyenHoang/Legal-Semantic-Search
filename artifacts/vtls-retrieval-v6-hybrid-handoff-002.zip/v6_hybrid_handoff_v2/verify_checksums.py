"""Cross-platform LF/CRLF-safe SHA-256 checksum verifier for Windows and Linux/macOS."""
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
lines = [l.strip() for l in (ROOT / "SHA256SUMS.txt").read_text(encoding="ascii").splitlines() if l.strip()]
mismatches = 0
for line in lines:
    expected_sha, rel_path = line.split("  ", 1)
    target = ROOT / rel_path
    actual_sha = hashlib.sha256(target.read_bytes()).hexdigest()
    if actual_sha != expected_sha:
        print(f"MISMATCH: {rel_path} (expected {expected_sha}, got {actual_sha})")
        mismatches += 1
print(f"Verified {len(lines)} files | Mismatches: {mismatches}")
raise SystemExit(0 if mismatches == 0 else 1)
